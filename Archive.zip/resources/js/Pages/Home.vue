<template>
    <h1>Home</h1>
    <p>{{ message }}</p>
</template>

<script setup>
const message = 'Hello I am inertial';
</script>