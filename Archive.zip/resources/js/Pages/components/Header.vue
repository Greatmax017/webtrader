<template>
    <!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
							<div class="dashboard_bar">
                                Neptune Web-Terminal
                            </div>
                        </div>
                        <div class="navbar-nav header-right">
							
							<div class="dz-side-menu">	
								<!-- <div class="search-coundry d-flex align-items-center">
									<img src="images/United.png" alt="">
									<select class="default-select dashboard-select image-select">
									  <option data-display="Eng">Eng</option>
									  <option value="2">Af</option>
									   <option value="2">Al</option>
									</select>
								</div> -->
									
								<!-- <ul>
									<li class="nav-item dropdown header-profile">
										<a class="nav-link" href="javascript:void(0);" role="button" data-bs-toggle="dropdown">
											<img src="/images/profile/pic1.jpg" alt="">
										</a>
										
									</li>
								</ul>	 -->
							</div>	
                        </div>
                    </div>
				</nav>
			</div>
		</div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->
</template>
<script>
export default {
    
}
</script>